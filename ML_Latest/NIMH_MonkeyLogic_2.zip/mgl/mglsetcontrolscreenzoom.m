function mglsetcontrolscreenzoom(zoom)

mdqmex(40,zoom);
