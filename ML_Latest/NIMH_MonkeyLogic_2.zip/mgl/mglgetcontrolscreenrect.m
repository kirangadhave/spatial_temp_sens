function rect = mglgetcontrolscreenrect()

rect = mdqmex(39);
