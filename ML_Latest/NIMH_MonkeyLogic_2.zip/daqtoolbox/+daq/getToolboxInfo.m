function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(Jan 2, 2018 build 53)';
