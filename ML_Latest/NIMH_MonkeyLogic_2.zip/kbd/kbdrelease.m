function kbdrelease_mexgen ()
% KBDRELEASE    Stop saving keystrokes.
%
% See also KBDINIT

% Mexgen generated this file on Wed Nov  6 12:05:31 2013
% DO NOT EDIT!

kbdmex (1);
