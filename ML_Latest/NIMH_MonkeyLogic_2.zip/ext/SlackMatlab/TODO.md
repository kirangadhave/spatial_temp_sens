# List of to-do items #

- [ ] Add support for ```multipart/form``` uploads via ```urlread2```.
- [ ] Add support for token-based authentication. Caching of auth token?
- [ ] Add support for posting files via [```files.upload```](https://api.slack.com/methods/files.upload) API.
- [ ] Add support for OAuth2 authentication.
